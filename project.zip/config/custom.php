<?php

return [

    'save' => ['message' => 'It Works Well! Save Data Successfully',  'alert-type' => 'success'],
    'edit' => ['message' => 'It Works Well! Edit Data Successfully',  'alert-type' => 'success'],
    'del' => ['message' => 'It Works Well! Delete Data Successfully',  'alert-type' => 'success'],
    'success' => ['message' => 'It Works Well! The Project Successfully Completed',  'alert-type' => 'success'],
    'error' => ['message' => 'Oh! Something error here.',  'alert-type' => 'error'],

    'watermark' => 'sodaighor.com',


];